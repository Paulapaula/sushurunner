<div class="about-container">
<div class="row">
<div class="col-md-4 col-md-offset-4">

Content for franchise 

</div>
</div>
</div>	