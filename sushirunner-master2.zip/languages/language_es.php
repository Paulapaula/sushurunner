<?php
// Web en Español
$texts = array(
    'sushirunner' => 'Sushi Runner',
	'menu' => 'Menú',
		'select-location' => 'Elige un local',
	'locations' => 'Locales',
	'specials' => 'Especiales',
	'catering' => 'Catering',
	'franchise' => 'Franquicias',
	'contact' => 'Contacto',
    'about-us' => 'Nosotros',
    	'privacy-policy' => 'Políticas de privacidad',
    	'general-terms' => 'Términos generales',
    	'employements' => 'Empleos',
    	'marketing-materials' => 'Materiales de marketing',
    	'rights-reserved' => 'Todos los derechos reservados',
		''
    );
?>