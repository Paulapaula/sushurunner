<?php
// Web en Inglés
$texts = array(
    'sushirunner' => 'Sushi Runner',
	'menu' => 'Menu',
		'select-location' => 'Select a location',
	'locations' => 'Locations',
	'specials' => 'Specials',
		'promo-1-title' => 'Entire dining check',
		'promo-1-desc' => 'Monday to friday 50% off on your entire dine&#8209;in check only.</p><p>Valid from 4:30pm to 7:30 pm not valid with any other offers, discount, coupons, or lunch special menu. Discount has not cash value, this offer is not available for online ordering.</p><p>Customer is responsible for all applicable taxes due on the free item.',
		'promo-2-title' => 'Buy two rolls for $15',
		'promo-2-desc' => 'Not valid with any other offers, discount, coupons, or lunch special menu.</p><p>This offer is not available for online ordering. customer is responsible for all applicable taxes.</p><p>You should ask for monthly special rolls, the restaurant is responsible to select the monthly rolls.',
		'promo-3-title' => '',
		'promo-3-desc' => '',
		'promo-4-title' => '',
		'promo-4-desc' => '',
		'promo-5-title' => '',
		'promo-5-desc' => '',
		'promo-6-title' => '',
		'promo-6-desc' => '',
	'catering' => 'Catering',
	'franchise' => 'Franchise',
	'contact' => 'Contact',
    'about-us' => 'About us',
    	'privacy-policy' => 'Privacy Policy',
    	'general-terms' => 'General Terms',
    	'employements' => 'Employements',
    	'marketing-materials' => 'Marketing materials',
    	'rights-reserved' => 'All Rights Reserved',
		''
    );
?>